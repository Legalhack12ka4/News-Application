package com.example.countrynews;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity  implements CategoryRVAdapter.CategoryClickInterace {

    private RecyclerView newsRV, categoryRV;
    private ProgressBar loadingPB;
    private ArrayList<Articles> articlesArrayList;
    private ArrayList<CategoryRVModal> categoryRVModalArrayList;
    private CategoryRVAdapter categoryRVAdapter;
    private NewsRVAdapter newsRVAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newsRV = findViewById(R.id.idRNews);
        categoryRV = findViewById(R.id.idRVCategories);
        loadingPB = findViewById(R.id.idPBLoading);
        articlesArrayList = new ArrayList<>();
        categoryRVModalArrayList= new ArrayList<>();
        newsRVAdapter = new NewsRVAdapter(articlesArrayList, this);
        categoryRVAdapter = new CategoryRVAdapter(categoryRVModalArrayList, this, this::onCategoryClick);
        newsRV.setLayoutManager(new LinearLayoutManager(this));
        newsRV.setAdapter(newsRVAdapter);
        categoryRV.setAdapter(categoryRVAdapter);
        getCategories();
        getNews("All");
        newsRVAdapter.notifyDataSetChanged();
    }
private void getCategories()
{
    categoryRVModalArrayList.add(new CategoryRVModal("All", "https://images.unsplash.com/photo-1516485042560-c18c0ac1e4a9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YWxsJTIwZmxhZ3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"));
    categoryRVModalArrayList.add(new CategoryRVModal("in", "https://images.unsplash.com/photo-1532375810709-75b1da00537c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8aW5kaWF8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"));
    categoryRVModalArrayList.add(new CategoryRVModal("th", "https://media.istockphoto.com/vectors/welcome-to-thailand-name-country-template-design-for-greeting-card-vector-id1183432276"));
    categoryRVModalArrayList.add(new CategoryRVModal("au", "https://previews.123rf.com/images/jpegwiz/jpegwiz1205/jpegwiz120500012/13652554-3d-model-of-australia-continent-with-name-.jpg?fj=1"));
    categoryRVModalArrayList.add(new CategoryRVModal("cn", "https://thumbs.dreamstime.com/b/china-flag-country-name-chinese-top-curled-over-to-reveal-text-50718168.jpg"));
    categoryRVModalArrayList.add(new CategoryRVModal("jp", "https://previews.123rf.com/images/kagenmi/kagenmi1502/kagenmi150200066/37056872-japan-flag-and-country-name.jpg?fj=1"));
    categoryRVModalArrayList.add(new CategoryRVModal("kr", "https://previews.123rf.com/images/ladiseno/ladiseno1308/ladiseno130800098/21324185-south-korea-text-on-special-background-allusive-to-the-flag.jpg?fj=1"));
    categoryRVModalArrayList.add(new CategoryRVModal("pk", "https://www.shutterstock.com/image-vector/flag-pakistan-pakistani-rectangle-frame-600w-1312408289.jpg"));
    categoryRVAdapter.notifyDataSetChanged();
}

private void getNews(String category)
{
loadingPB.setVisibility(View.VISIBLE);
articlesArrayList.clear();
String categoryURL="https://newsdata.io/api/1/news?apikey=pub_11187565b504fef2702e8d36ee8d6c7e18e84&country="+category+"";
String url="https://newsdata.io/api/1/news?apikey=pub_11187565b504fef2702e8d36ee8d6c7e18e84";
String BASE_URL="https://newsdata.io/";
    Retrofit retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
    RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
    Call<NewsModal> call;
    if(category.equals("All"))
    {
    call = retrofitAPI.getAllNews(url);
    }
    else
    {
    call=retrofitAPI.getNewsByCategory(categoryURL);
    }
call.enqueue(new Callback<NewsModal>() {
    @Override
    public void onResponse(Call<NewsModal> call, Response<NewsModal> response) {
   try {
       NewsModal newsModal = response.body();
       loadingPB.setVisibility(View.GONE);
       ArrayList<Articles> articles = newsModal.getResults();
       for(int i=0; i<articles.size(); i++)
       {
           articlesArrayList.add(new Articles(articles.get(i).getTitle(),articles.get(i).getDescription(),articles.get(i).getImage_url(),articles.get(i).getLink(), articles.get(i).getContent()));
       }
       newsRVAdapter.notifyDataSetChanged();

   }
   catch (Exception e)
   {
       Toast.makeText(MainActivity.this,"Something went wrong", Toast.LENGTH_LONG).show();
   }
   }



    @Override
    public void onFailure(Call<NewsModal> call, Throwable t) {
        Toast.makeText(MainActivity.this,"Fail to get news", Toast.LENGTH_LONG).show();
    }
});
}

    @Override
    public void onCategoryClick(int position) {
    String category = categoryRVModalArrayList.get(position).getCountry();
    getNews(category);
    }
}