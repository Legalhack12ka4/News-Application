package com.example.countrynews;

public class CategoryRVModal {
private String country;
private String categoryImageUrl;

        public String getCountry() {
                return country;
        }

        public void setCountry(String country) {
                this.country = country;
        }

        public String getCategoryImageUrl() {
                return categoryImageUrl;
        }

        public void setCategoryImageUrl(String categoryImageUrl) {
                this.categoryImageUrl = categoryImageUrl;
        }

        public CategoryRVModal(String country, String categoryImageUrl) {
                this.country = country;
                this.categoryImageUrl = categoryImageUrl;


        }
}
